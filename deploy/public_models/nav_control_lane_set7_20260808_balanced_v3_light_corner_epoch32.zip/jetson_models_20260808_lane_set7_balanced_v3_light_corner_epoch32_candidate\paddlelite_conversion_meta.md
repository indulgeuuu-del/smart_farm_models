# PaddleLite 转换记录

转换工具：`paddlelite 2.13rc0`

```powershell
& ".venv_paddlelite_opt\Scripts\python.exe" ".venv_paddlelite_opt\Scripts\paddle_lite_opt" `
  --model_file="cnn_lane.pdmodel" `
  --param_file="cnn_lane.pdiparams" `
  --optimize_out="cnn_lane" `
  --valid_targets=arm `
  --optimize_out_type=naive_buffer
```

结果：`cnn_lane.nb` 成功生成。Windows 本机完成结构加载检查；由于本机不是 Jetson ARM 运行平台，未把 Windows 的数值输出写成 ARM 数值验收结论。
