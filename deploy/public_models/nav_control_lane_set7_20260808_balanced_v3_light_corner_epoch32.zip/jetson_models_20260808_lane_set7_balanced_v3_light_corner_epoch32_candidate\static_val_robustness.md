# 巡航模型鲁棒性离线评估

- 模型：`E:\Codex\Project\smart_farm_models\deploy\exported_models\nav_control_optional\lane_set7_balanced_v3_light_corner_epoch32_static_20260808\cnn_lane`
- 数据：`E:\Codex\Project\smart_farm_models\datasets\08_nav_control_optional\paddle_custom\lane_set7_balanced_v2_val52_54_test51_reserved_20260725\val`
- 光照压力变体：`original`
- 样本：`3857`
- 全局 MAE：`0.031453`
- 方向错误率：`0.000956`
- 欠转率：`0.058317`
- 输出变化 P95：`0.061505`
- 尖峰数：`20`

| session | records | global MAE | corner score | delta P95 | spikes |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 52 | 1902 | 0.036717 | 0.087258 | 0.061334 | 12 |
| 54 | 1955 | 0.026332 | 0.049035 | 0.061520 | 8 |
