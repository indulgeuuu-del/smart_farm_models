# 巡航模型鲁棒性离线评估

- 模型：`<repo-root>\outputs\nav_control_optional\lane_set7_balanced_v3_light_corner_20260807\dynamic\eval_snapshots\epoch_032\cnn_lane.pdparams`
- 数据：`<repo-root>\datasets\08_nav_control_optional\paddle_custom\lane_set7_balanced_v2_val52_54_test51_reserved_20260725\test`
- 光照压力变体：`right_shadow`
- 样本：`1889`
- 全局 MAE：`0.031282`
- 方向错误率：`0.007767`
- 欠转率：`0.093204`
- 输出变化 P95：`0.065864`
- 尖峰数：`3`

| session | records | global MAE | corner score | delta P95 | spikes |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 51 | 1889 | 0.031282 | 0.099945 | 0.065864 | 3 |
