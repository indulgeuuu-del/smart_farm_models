# 巡航模型鲁棒性离线评估

- 模型：`<repo-root>\outputs\nav_control_optional\lane_set7_balanced_v3_light_corner_20260807\dynamic\eval_snapshots\epoch_032\cnn_lane.pdparams`
- 数据：`<repo-root>\datasets\08_nav_control_optional\paddle_custom\lane_set7_original_labels_session54_val_20260724\val`
- 光照压力变体：`left_shadow`
- 样本：`1955`
- 全局 MAE：`0.026839`
- 方向错误率：`0.000000`
- 欠转率：`0.019342`
- 输出变化 P95：`0.063211`
- 尖峰数：`8`

| session | records | global MAE | corner score | delta P95 | spikes |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 54 | 1955 | 0.026839 | 0.048868 | 0.063211 | 8 |
