# lane_set(7) Balanced V3 Light-Corner epoch 32 巡航候选

本目录交付 `lane_set(7) 20260724_185938` 的 Balanced V3 Light-Corner epoch 32 候选。训练和评估使用不含紫色区域的独立数据副本；原始数据、旧 epoch 45 和 Balanced V2 交付包均未覆盖。

## 推荐文件

```text
nav_control_optional/cnn_lane.nb
```

该包是新的独立 A/B 候选，不应直接覆盖 Jetson 当前模型。epoch 32 的选择依据是同时比较 validation session 54、独立 test session 51、弯道分段和 9 种确定性光照压力变体。它不是单一 session 的最低 MAE 轮次，但在未参与训练的 session 51 上整体最均衡；epoch 50 和 epoch 62 在该独立 session 上出现回落。

## 固定接口

- 输入：`[N, 3, 128, 128]`
- 输出：`[N, 2]`
- `output_0 = deviation`
- `output_1 = compatibility zero`
- 未执行 `--swap-outputs`

## 训练口径

- 数据源：`lane_set(7) 20260724_185938`
- 紫色区域：不进入 train、validation 或 test
- 划分：train session `4,5,6,8,14,16,18,27,34,35,36,37,39,40,42,43,44,45,47,48,49,50`；validation session `52,54`；独立 test session `51`
- 每个 session 去尾 `100` 帧，并过滤起步零速帧
- 上限 `120` epoch，实际早停于 `62` epoch
- `AdamW`，学习率峰值 `0.00035`，`weight_decay=0.0001`
- 5 轮 warmup + cosine 衰减，最低学习率 `0.000005`
- batch/eval batch：`128/256`
- `corner_focus_v1` + `light_corner_v3`
- seed：`20260807`，设备：`gpu:0`

完整配置见 `training_config.yaml`，完整训练历史见 `training_metrics.json`。

## 离线结果

### session 54（模型选择共同留出集）

静态模型完整评估覆盖 validation 的 session 52、54，共 `3,857` 张；其中 session 54 单独结果为：

| 指标 | session 54 |
| --- | ---: |
| global MAE | `0.026332` |
| corner score | `0.049035` |
| 欠转率 | `2.321%` |
| 方向错误率 | `0` |
| 连续帧变化 P95 | `0.061520` |
| 尖峰数 | `8` |

### session 51（独立 test）

| 指标 | 原始 test |
| --- | ---: |
| global MAE | `0.031196` |
| transition MAE | `0.170731` |
| corner MAE | `0.154349` |
| hard MAE | `0.034471` |
| 欠转率 | `8.932%` |
| 方向错误率 | `0.583%` |
| 连续帧变化 P95 | `0.070255` |
| 尖峰数 | `5` |

9 种光照压力变体的逐项报告位于 `light_stress/session54/` 和 `light_stress/test51/`。其中 session 51 的最差值为：global MAE `0.031652`、corner MAE `0.157261`、欠转率 `9.515%`、变化 P95 `0.069611`；这些是压力变体中的最大值，不代表所有未知赛场光照都已覆盖。

## 导出与验证

- Paddle `2.6.1` 静态导出回载形状：`[1,2]`
- validation `3,857` 张、test `1,889` 张逐批动态/静态对照：最大绝对差 `0`
- 动态/静态 `output_0` 均有非零响应；两者 `output_1` 最大绝对值均为 `0`
- PaddleLite `2.13rc0` 使用 `valid_targets=arm`、`optimize_out_type=naive_buffer` 转换成功
- Windows 已完成 `.nb` 结构加载，输入形状为 `[1,3,128,128]`，输出形状为 `[1,2]`

Windows x86 主机不能替代 Jetson ARM 运行时做 `.nb` 数值验收；旧的 ARM 包在同一主机运行库下也会出现无效数值，因此本包的 ARM 数值推理和实车闭环仍标记为待 Jetson 验证。

## Jetson A/B 建议

先备份当前模型，再临时替换：

```bash
sha256sum -c SHA256SUMS.txt
cp /path/to/smartcar_baidu_21/src/cnn_lane.nb \
  /path/to/smartcar_baidu_21/src/cnn_lane.before_lane_set7_balanced_v3_epoch32.nb
cp nav_control_optional/cnn_lane.nb \
  /path/to/smartcar_baidu_21/src/cnn_lane.nb
```

A/B 时保持速度、转向增益、输出平滑、下位机固件、赛道、载荷和测试方向一致。先低速完成整圈，再重点通过“锐角弯 + 两连直角急弯”，每版至少记录 3 圈的出界、人工接管、欠转、抖动和完整圈数。只有实车闭环也优于旧 epoch 45，才替换正式模型。

## 文件说明

- `nav_control_optional/cnn_lane.nb`：上车 PaddleLite ARM 模型
- `nav_control_optional/cnn_lane.pdmodel` / `cnn_lane.pdiparams`：Paddle 静态模型
- `nav_control_optional/cnn_lane.pdparams`：epoch 32 动态 checkpoint
- `static_val_robustness.*`、`test_session51_results.*`：静态模型原始评估
- `light_stress/`：两套 session 的 9 种确定性光照压力报告
- `training_config.yaml`、`training_metrics.json`：训练配置和完整训练记录
- `SHA256SUMS.txt`：包内文件校验和

