# 巡航模型鲁棒性离线评估

- 模型：`<repo-root>\deploy\exported_models\nav_control_optional\lane_set7_balanced_v3_light_corner_epoch32_static_20260808\cnn_lane`
- 数据：`<repo-root>\datasets\08_nav_control_optional\paddle_custom\lane_set7_balanced_v2_val52_54_test51_reserved_20260725\test`
- 光照压力变体：`original`
- 样本：`1889`
- 全局 MAE：`0.031196`
- 方向错误率：`0.005825`
- 欠转率：`0.089320`
- 输出变化 P95：`0.070255`
- 尖峰数：`5`

| session | records | global MAE | corner score | delta P95 | spikes |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 51 | 1889 | 0.031196 | 0.099895 | 0.070255 | 5 |
